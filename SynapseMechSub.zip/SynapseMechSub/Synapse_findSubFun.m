function [SURFHR1,SURFHR2,SYNAPSEHR1,SYNAPSEHR2]=Synapse_findSubFun(SURF1,SURF2,LIM,FRAMES,Count)
 
h = waitbar(0,['Determining cell-cell interfaces for data set ' num2str(Count)]);

for l=1:FRAMES(end)
    
    waitbar(l/FRAMES(end))
    
INDEX1{l}=find(SURF1.TIME==l);
INDEX2{l}=find(SURF2.TIME==l);

if ~isempty(INDEX1{l})&~isempty(INDEX2{l})

%% Define HighRes Surfaces (Voxels)

[Faces1{l},VerticesVox1{l}] = isosurface(double(SURF1.MASK{INDEX1{l}}),0.1);
[Faces2{l},VerticesVox2{l}] = isosurface(double(SURF2.MASK{INDEX2{l}}),0.1);

%% Define HighRes Surfaces (um)

Vertices1{l}(:,1)=(VerticesVox1{l}(:,2)-.5).*SURF1.RESMASK(1,2); % Vertices High res surface 1
Vertices1{l}(:,2)=(VerticesVox1{l}(:,1)-.5).*SURF1.RESMASK(1,1); % Vertices High res surface 1
Vertices1{l}(:,3)=(VerticesVox1{l}(:,3)-.5).*SURF1.RESMASK(1,3); % Vertices High res surface 1

Vertices2{l}(:,1)=(VerticesVox2{l}(:,2)-.5).*SURF2.RESMASK(1,2); % Vertices High res surface 2
Vertices2{l}(:,2)=(VerticesVox2{l}(:,1)-.5).*SURF2.RESMASK(1,1); % Vertices High res surface 2
Vertices2{l}(:,3)=(VerticesVox2{l}(:,3)-.5).*SURF2.RESMASK(1,3); % Vertices High res surface 2

%% Output 1

SURFHR1.VERT{l}=Vertices1{l};
SURFHR1.FACES{l}=Faces1{l};
SURFHR2.VERT{l}=Vertices2{l};
SURFHR2.FACES{l}=Faces2{l};


%% Define Interface (Voxels)

Vert1_mask_IND{l}=find(SURF1.MASK{INDEX1{l}}==1); %find voxel indices defining mask 1
Vert2_mask_IND{l}=find(SURF2.MASK{INDEX2{l}}==1); %find voxel indices defining mask 2

[Vert1_mask_VOX{l}(:,2),Vert1_mask_VOX{l}(:,1),Vert1_mask_VOX{l}(:,3)]=ind2sub(size(SURF1.MASK{INDEX1{l}}), Vert1_mask_IND{l});% find voxel positions
[Vert2_mask_VOX{l}(:,2),Vert2_mask_VOX{l}(:,1),Vert2_mask_VOX{l}(:,3)]=ind2sub(size(SURF2.MASK{INDEX2{l}}), Vert2_mask_IND{l});% find voxel positions

idx1_Syn1{l} = rangesearch(Vert2_mask_VOX{l},VerticesVox1{l},LIM);

idxcount1_Syn1{l}=find(~cellfun(@isempty,idx1_Syn1{l}));

idx2_Syn2{l} = rangesearch(Vert1_mask_VOX{l},VerticesVox2{l},LIM);

idxcount2_Syn2{l}=find(~cellfun(@isempty,idx2_Syn2{l}));

if ~isempty(idxcount1_Syn1{l})&~isempty(idxcount2_Syn2{l})

InterfaceVox1=VerticesVox1{l}(idxcount1_Syn1{l},:);
InterfaceVox2=VerticesVox2{l}(idxcount2_Syn2{l},:);

%% Output 2A

SYNAPSEHR1.VERT{l}(:,1)=(InterfaceVox1(:,2)-0.5).*SURF1.RESMASK(1,2);
SYNAPSEHR1.VERT{l}(:,2)=(InterfaceVox1(:,1)-0.5).*SURF1.RESMASK(1,1);
SYNAPSEHR1.VERT{l}(:,3)=(InterfaceVox1(:,3)-0.5).*SURF1.RESMASK(1,3);

SYNAPSEHR2.VERT{l}(:,1)=(InterfaceVox2(:,2)-0.5).*SURF2.RESMASK(1,2);
SYNAPSEHR2.VERT{l}(:,2)=(InterfaceVox2(:,1)-0.5).*SURF2.RESMASK(1,1);
SYNAPSEHR2.VERT{l}(:,3)=(InterfaceVox2(:,3)-0.5).*SURF2.RESMASK(1,3);

clear InterfaceVox1 InterfaceVox2

SYNAPSEHR1.VERT_ID{l}=idxcount1_Syn1{l};
SYNAPSEHR2.VERT_ID{l}=idxcount2_Syn2{l};

%% Determine distances 

[ID1{l},D1{l}]=knnsearch(SYNAPSEHR2.VERT{l},SYNAPSEHR1.VERT{l}); 
[ID2{l},D2{l}]=knnsearch(SYNAPSEHR1.VERT{l},SYNAPSEHR2.VERT{l}); 

%% Output 2B

SYNAPSEHR1.DISTANCES{l}=D1{l};
SYNAPSEHR2.DISTANCES{l}=D2{l};

else
    
SYNAPSEHR1.VERT{l}=double.empty(0,3);
SYNAPSEHR2.VERT{l}=double.empty(0,3);
SYNAPSEHR1.VERT_ID{l}=[];
SYNAPSEHR2.VERT_ID{l}=[];
SYNAPSEHR1.DISTANCES{l}=[];
SYNAPSEHR2.DISTANCES{l}=[];
    
end

else
    
SURFHR1.VERT{l}=double.empty(0,3);
SURFHR2.VERT{l}=double.empty(0,3);
SURFHR1.FACES{l}=double.empty(0,3);
SURFHR2.FACES{l}=double.empty(0,3);


SYNAPSEHR1.VERT{l}=double.empty(0,3);
SYNAPSEHR2.VERT{l}=double.empty(0,3);
SYNAPSEHR1.VERT_ID{l}=[];
SYNAPSEHR2.VERT_ID{l}=[];
SYNAPSEHR1.DISTANCES{l}=[];
SYNAPSEHR2.DISTANCES{l}=[];
end

end

close(h)

end
