function [TailLength,TailVolume,TimeOfContact]=Tail_lengthFun(Input,SURF,NO_FILES)

for i=1:NO_FILES
    
      % Select cell Surface (only implemented for T cell tail)
    
    
     if ~isempty(SURF{i,1})
        
        SURFTEMP=SURF{i,1};
        
    elseif ~isempty(SURF{i,2})
        
        SURFTEMP=SURF{i,2};
     
    else
        
        SURFTEMP=[];
        
     end
     
     % Determine pipette position
    
     if ~isempty(SURFTEMP)&~isempty(Input{i}.DataOut.SpotsPipetteTip)
         
         TimeOfContact(i)=Input{i}.DataOut.SpotsPipetteTip(1,5);
    
        
        if size(Input{i}.DataOut.SpotsPipetteTip,1)>1 % more than one spot created, take mean position
        
        PipetteX(i)=mean(Input{i}.DataOut.SpotsPipetteTip(:,1));
        
        else
            
            PipetteX(i)=Input{i}.DataOut.SpotsPipetteTip(:,1); % only one spot created
            
        end
        
        Centroid=sum(SURFTEMP.VERT{TimeOfContact(i)})/numel(SURFTEMP.VERT{TimeOfContact(i)}(:,1));
        
        Centroid_X=Centroid(:,1);
        
   if Centroid_X<=PipetteX(i)
       

    for l=1:numel(SURFTEMP.VERT)
        
        if ~isempty(SURFTEMP.VERT{l})
              
            TailLength{i}(l)=PipetteX(i)-min(SURFTEMP.VERT{l}(:,1));
            
            MaskTail=SURFTEMP.MASK{l}(1:round(PipetteX(i)./SURFTEMP.RESMASK(1)),:,:);
            
            VoxelsTail=numel(find(MaskTail==1));
            VoxelsMaskTail=size(MaskTail,1)*size(MaskTail,2)*size(MaskTail,3);
            
            VolumeMaskTail=VoxelsMaskTail*SURFTEMP.RESMASK(1)*SURFTEMP.RESMASK(2)*SURFTEMP.RESMASK(3);
            
            TailVolume{i}(l)=VoxelsTail/VoxelsMaskTail*VolumeMaskTail;
            
        else
            
         TailLength{i}(l)=NaN;  
         TailVolume{i}(l)=NaN;
            
        end
    end
            
            
   else 
            
       for l=1:numel(SURFTEMP.VERT)
           
           if ~isempty(SURFTEMP.VERT{l})
            
            TailLength{i}(l)=max(SURFTEMP.VERT{l}(:,1))-PipetteX(i);
            
            MaskTail=SURFTEMP.MASK{l}(round(PipetteX(i)./SURFTEMP.RESMASK(1)):end,:,:);
            
            VoxelsTail=numel(find(MaskTail==1));
            VoxelsMaskTail=size(MaskTail,1)*size(MaskTail,2)*size(MaskTail,3);
            
            VolumeMaskTail=VoxelsMaskTail*SURFTEMP.RESMASK(1)*SURFTEMP.RESMASK(2)*SURFTEMP.RESMASK(3);
            
            TailVolume{i}(l)=VoxelsTail/VoxelsMaskTail*VolumeMaskTail;
            
             else
            
         TailLength{i}(l)=NaN;  
         TailVolume{i}(l)=NaN;
            
        end
        end
        
        clear MaskTail VoxelsTail VoxelsMaskTail VolumeMaskTail
        
        end
        

    
     else
         
         TimeOfContact(i)=NaN;
    
     end
    
end



end
    
    
    
    
    
