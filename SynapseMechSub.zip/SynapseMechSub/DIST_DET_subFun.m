function [DISTANCES,CURVATURES,DEGRANULATIONPOCKETS]=DIST_DET_subFun(SPOTS,SYNAPSEHR1,SYNAPSEHR2,SYNAPSECURVATURE1,SYNAPSECURVATURE2,FRAMES,Count)
 
h = waitbar(0,['Determining spots-interface distances and degranulation pockets for data set' num2str(Count)]);


for l=1:FRAMES(end)
    
    waitbar(l/FRAMES(end))
    
    if ~isempty(SYNAPSEHR1.VERT{l})&~isempty(SPOTS.XYZ{l})
    
  
        
   [ID{l},DISTANCES{1}.ALL{l}]=knnsearch(SYNAPSEHR1.VERT{l},SPOTS.XYZ{l});
   
   
   DISTANCES{1}.MEDIAN(l)=nanmedian(DISTANCES{1}.ALL{l});
   DISTANCES{1}.MEAN(l)=nanmean(DISTANCES{1}.ALL{l});
   DISTANCES{1}.STD(l)=nanstd(DISTANCES{1}.ALL{l});
   
   CURVATURES{1}.CMean{l}=SYNAPSECURVATURE1.CMean_Map{l}(ID{l});
   CURVATURES{1}.CGauss{l}=SYNAPSECURVATURE1.CGauss_Map{l}(ID{l});   
   
   DEGRANULATIONPOCKETS{1}.VERT{l}=SYNAPSEHR1.VERT{l}(ID{l},:);
        
    else
        
     DISTANCES{1}.ALL{l}=NaN;
     DISTANCES{1}.MEDIAN(l)=NaN;
     DISTANCES{1}.MEAN(l)=NaN;
     DISTANCES{1}.STD(l)=NaN;
     CURVATURES{1}.CMean{l}=NaN;
     CURVATURES{1}.CGauss{l}=NaN;
     DEGRANULATIONPOCKETS{1}.VERT{l}=NaN;
     
    end
    
    
   
    if ~isempty(SYNAPSEHR1.VERT{l})&~isempty(SPOTS.XYZ{l})
        
   [ID2{l},DISTANCES{2}.ALL{l}]=knnsearch(SYNAPSEHR2.VERT{l},SPOTS.XYZ{l});
   
   
   DISTANCES{2}.MEDIAN(l)=nanmedian(DISTANCES{2}.ALL{l});
   DISTANCES{2}.MEAN(l)=nanmean(DISTANCES{2}.ALL{l});
   DISTANCES{2}.STD(l)=nanstd(DISTANCES{2}.ALL{l});
   
   CURVATURES{2}.CMean{l}=SYNAPSECURVATURE2.CMean_Map{l}(ID2{l});
   CURVATURES{2}.CGauss{l}=SYNAPSECURVATURE2.CGauss_Map{l}(ID2{l});   
   
   DEGRANULATIONPOCKETS{2}.VERT{l}=SYNAPSEHR2.VERT{l}(ID2{l},:);
        
    else
        
     DISTANCES{2}.ALL{l}=NaN;
     DISTANCES{2}.MEDIAN(l)=NaN;
     DISTANCES{2}.MEAN(l)=NaN;
     DISTANCES{2}.STD(l)=NaN;
     CURVATURES{2}.CMean{l}=NaN;
     CURVATURES{2}.CGauss{l}=NaN;
     DEGRANULATIONPOCKETS{2}.VERT{l}=NaN;
     
    end
    

end

close(h)
end
