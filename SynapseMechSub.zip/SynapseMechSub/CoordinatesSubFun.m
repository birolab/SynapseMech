function Output=CoordinatesSubFun(Input,Count,Indicator)

  h = waitbar(0,['Getting surface coordinates for data set ' num2str(Count) ', surface ' num2str(Indicator)]);
  
for l=Input{1,3}+1:Input{end,3}+1
    
    waitbar(l/(Input{end,3}+1))
    
   INDEX{l}=find(cell2mat(Input(:,3))==l-1);
   
   if ~isempty(INDEX{l})
    
   Output.VERT{l}=Input{INDEX{l}}-Input{INDEX{l},7}; %translate coordinate system so that it starts at [0 0 0]
   Output.FACES{l}=Input{INDEX{l},4}+1; % Matlab can't handle 0 entries for faces
   
   MASK_OR{l}=Input{INDEX{l},5};
   
   % keep largest element only
   
   CC = bwconncomp(MASK_OR{l});
   numPixels = cellfun(@numel,CC.PixelIdxList);
   [~,idx] = max(numPixels);
   
   
   
   MASKTemp = false(size(MASK_OR{l}));
   MASKTemp(CC.PixelIdxList{idx}) = true;
   
   clear CC numPixels idx
   
   % close holes in retained largest element
   
   CC=bwconncomp(~ MASKTemp);
   numPixels = cellfun(@numel,CC.PixelIdxList);
   [~,idx] = max(numPixels);
   
   CC.PixelIdxList{idx}=[];
   
   if isempty(cell2mat(CC.PixelIdxList(:)))
       
       Output.MASK{l}=MASKTemp;
       
   else
       
       MASKTemp(cell2mat(CC.PixelIdxList(:)))=1;
       Output.MASK{l}=MASKTemp;
       
   end


   clear CC numPixels idx
   
   
   Output.TIME(l)=l-1;
   Output.RES(:,1)=Input{INDEX{l},6}(1,1);
   Output.RES(:,2)=Input{INDEX{l},6}(1,2);
   Output.RES(:,3)=Input{INDEX{l},6}(1,3);
    
   Output.RESMASK(:,1)=(Input{INDEX{l},6}(1,1)/Input{INDEX{l},9}(1,1));
   Output.RESMASK(:,2)=(Input{INDEX{l},6}(1,2)/Input{INDEX{l},9}(1,2));
   Output.RESMASK(:,3)=(Input{INDEX{l},6}(1,3)/Input{INDEX{l},9}(1,3));
    
   Output.SizeFOV(:,1)=size(Input{1,5},1)*Input{1,6}(1,1)/Input{1,9}(1,1);
   Output.SizeFOV(:,2)=size(Input{1,5},2)*Input{1,6}(1,2)/Input{1,9}(1,2);
   Output.SizeFOV(:,3)=size(Input{1,5},3)*Input{1,6}(1,3)/Input{1,9}(1,3);
   
   else
       
   Output.VERT{l}=NaN;
   Output.FACES{l}=NaN;
   Output.MASK{l}=NaN;
   Output.TIME(l)=NaN;  
       
       
       
   end
end

close(h)


end