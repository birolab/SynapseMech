function [SURFCURVATURE,SYNAPSECURVATURE]=Curvature_detFun(SURF,SYNAPSEHR,NO_FILES)

for i=1:NO_FILES
   
        
 if ~isempty(SURF{i,1}) 
     
 [SURFCURVATURE{i,1},SURFCURVATURE{i,2},SYNAPSECURVATURE{i,1},SYNAPSECURVATURE{i,2}]=Curvature_detSubFun(SURF{i,1},SURF{i,3},SYNAPSEHR{i,1},SYNAPSEHR{i,2});
         
 elseif ~isempty(SURF{i,2}) 
     
  warning('Curvature maps of the Lifeact-signal based interface should not be used!')
   
 [SURFCURVATURE{i,1},SURFCURVATURE{i,2},SYNAPSECURVATURE{i,1},SYNAPSECURVATURE{i,2}]=Curvature_detSubFun(SURF{i,2},SURF{i,3},SYNAPSEHR{i,1},SYNAPSEHR{i,2});
        
     
 end
 
end
end