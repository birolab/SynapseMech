function [SURF1CURVATURE,SURF2CURVATURE,SYNAPSE1CURVATURE,SYNAPSE2CURVATURE]=Curvature_detSubFun(SURF1,SURF2,SYNAPSEHR1,SYNAPSEHR2,Count)

  h = waitbar(0,['Determining 3D curvatures for data set ' num2str(Count)]);



   for l=1:numel(SYNAPSEHR1.VERT)
       
       waitbar(l/numel(SYNAPSEHR1.VERT))
     
  
       if ~isempty(SYNAPSEHR1.VERT{l})
           
FV1.vertices=SURF1.VERT{l};
FV1.faces=SURF1.FACES{l};

FV2.vertices=SURF2.VERT{l};
FV2.faces=SURF2.FACES{l};
            
        
[SURF1CURVATURE.CMean{l},SURF1CURVATURE.CGauss{l},Dir1,Dir2,Lambda1,Lambda2]=patchcurvature(FV1,true);
[SURF2CURVATURE.CMean{l},SURF2CURVATURE.CGauss{l},Dir1,Dir2,Lambda1,Lambda2]=patchcurvature(FV2,true);


[IdxMap1,DMap1]=knnsearch(SURF1.VERT{l},SYNAPSEHR1.VERT{l});
SYNAPSE1CURVATURE.CMean_Map{l}=SURF1CURVATURE.CMean{l}(IdxMap1); % Curvature High res interface 1
SYNAPSE1CURVATURE.CGauss_Map{l}=SURF1CURVATURE.CGauss{l}(IdxMap1); % Curvature High res interface 1


[IdxMap2,DMap2]=knnsearch(SURF2.VERT{l},SYNAPSEHR2.VERT{l});
SYNAPSE2CURVATURE.CMean_Map{l}=SURF2CURVATURE.CMean{l}(IdxMap2); % Curvature High res interface 2
SYNAPSE2CURVATURE.CGauss_Map{l}=SURF2CURVATURE.CGauss{l}(IdxMap2); % Curvature High res interface 2


 else
         SURF1CURVATURE.CMean{l}=NaN;
         SURF1CURVATURE.CGauss{l}=NaN;
         SURF2CURVATURE.CMean{l}=NaN;
         SURF2CURVATURE.CGauss{l}=NaN;
         
         SYNAPSE1CURVATURE.CMean_Map{l}=NaN;
         SYNAPSE1CURVATURE.CGauss_Map{l}=NaN;
         SYNAPSE2CURVATURE.CMean_Map{l}=NaN;
         SYNAPSE2CURVATURE.CGauss_Map{l}=NaN;
         
       
            
        end 
 
 
 
 
 
 
   end

   close(h)


end


