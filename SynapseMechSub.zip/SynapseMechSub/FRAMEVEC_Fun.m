function FRAMES=FRAMEVEC_Fun(SURF,SPOTS,NO_FILES)


for i=1:NO_FILES
    
    if ~isempty(SURF{i,1})
    
        MaxFrame(1)=max(SURF{i,1}.TIME)+1;
        
    else
        
        MaxFrame(1)=NaN;
        
    end
    
    
        if ~isempty(SURF{i,2})
    
        MaxFrame(2)=max(SURF{i,2}.TIME)+1;
        
    else
        
        MaxFrame(2)=NaN;
        
        end
    
    if ~isempty(SURF{i,3})
    
        MaxFrame(3)=max(SURF{i,3}.TIME)+1;
        
    else
        
        MaxFrame(3)=NaN;
        
               end
               
      if ~isempty(SPOTS{i})
          
        MaxFrame(4)=max(SPOTS{i}.TIME)+1;
      else
          
          MaxFrame(4)=NaN;
      end
    
               
  FRAMES{i}=1:max(MaxFrame);  
    
    
    
end




end