function  [AREA, SYNAPSE_FACES]=Synapse_AreaFun(SYNAPSEHR,SURFHR,NO_FILES)

for i=1:NO_FILES
   

                   
[AREA{i,1}, SYNAPSE_FACES{i,1}]=Synapse_AreaSubFun(SYNAPSEHR{i,1},SURFHR{i,1});
[AREA{i,2}, SYNAPSE_FACES{i,2}]=Synapse_AreaSubFun(SYNAPSEHR{i,2},SURFHR{i,2});  

   
    
end





end