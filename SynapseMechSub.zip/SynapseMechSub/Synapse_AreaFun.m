function  [AREA, SYNAPSE_FACES]=Synapse_AreaFun(SYNAPSEHR,SURFHR,NO_FILES,FRAMES)

for i=1:NO_FILES
   

                   
[AREA{i,1}, SYNAPSE_FACES{i,1}]=Synapse_AreaSubFun(SYNAPSEHR{i,1},SURFHR{i,1},FRAMES{i},i,1);
[AREA{i,2}, SYNAPSE_FACES{i,2}]=Synapse_AreaSubFun(SYNAPSEHR{i,2},SURFHR{i,2},FRAMES{i},i,2);  

   close all
    
end





end