function [SURFHR,SYNAPSEHR]=Synapse_findFun(SURF,NO_FILES,LIM,FRAMES)

for i=1:NO_FILES
   

        
 if ~isempty(SURF{i,1}) 
     
 [SURFHR{i,1},SURFHR{i,2},SYNAPSEHR{i,1},SYNAPSEHR{i,2}]=Synapse_findSubFun(SURF{i,1},SURF{i,3},LIM,FRAMES{i},i);
         
 elseif ~isempty(SURF{i,2}) 
     
  warning('Lifeact-signal based surface will be used for interface determination!')
  warning('Curvature maps of the Lifeact-signal based interface should not be used!')
   
 [SURFHR{i,1},SURFHR{i,2},SYNAPSEHR{i,1},SYNAPSEHR{i,2}]=Synapse_findSubFun(SURF{i,2},SURF{i,3},LIM,FRAMES{i},i);
        
     
 end
 


end
end